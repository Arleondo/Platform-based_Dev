const addBtn = document.querySelector(".add");

const input = document.querySelector(".inp-group");

function removeInput(){
    this.parentElement.remove();
}


function addInput (){
    const Puesto= document.createElement("input");
    Puesto.type= "text";
    Puesto.placeholder = "Puesto/empleo";

    const Fecha = document.createElement("input");
    Fecha.type= "text";
    Fecha.placeholder= "De-Al" ;

    const btn = document.createElement("a");
    btn.className = "delete";
    btn.innerHTML = "&times";

    btn.addEventListener("click", removeInput)

    const flex=document.createElement("div");
    flex.className = "flex"

    input.appendChild(flex);
    flex.appendChild(Puesto);
    flex.appendChild(Fecha);
    flex.appendChild(btn);

}

addBtn.addEventListener("click", addInput);