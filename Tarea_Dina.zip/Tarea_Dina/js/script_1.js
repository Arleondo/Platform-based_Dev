const addBtn = document.querySelector(".add1");

const input = document.querySelector(".inp-group1");


function addInput_1 (){
    const Formacion= document.createElement("input");
    Formacion.type= "text";
    Formacion.placeholder = "Formacion";

    const Lugar = document.createElement("input");
    Lugar.type= "text";
    Lugar.placeholder= "De-Al" ;

    const btn = document.createElement("a");
    btn.className = "delete";
    btn.innerHTML = "&times";

    btn.addEventListener("click", removeInput)

    const flex_1=document.createElement("div");
    flex_1.className = "flex"

    input.appendChild(flex_1);
    flex_1.appendChild(Formacion);
    flex_1.appendChild(Lugar);
    flex_1.appendChild(btn);

}

addBtn.addEventListener("click", addInput_1);